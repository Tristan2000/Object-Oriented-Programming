/*
Tristan Jones
11/1/2021
*/
import java.util.Scanner;
public class Triangle 
	{
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the length of each side of the triangle: ");
		double side1 = input.nextDouble();
		double side2 = input.nextDouble();
		double side3 = input.nextDouble();
		String color = "white";
		String fill = " ";
		System.out.print("Enter the color of the triangle: ");
		color = input.next();
		boolean filled = false;
		System.out.print("Is the Triangle filled? Yes or No: ");
		fill = input.next();
		
		SimpleTriangle newTriangle = new SimpleTriangle(side1, side2, side3, color, filled);
		newTriangle.setColor(color);
		if(fill.compareToIgnoreCase("Yes") == 0){
			filled = true;
		}
		newTriangle.setFilled(filled);
		
		System.out.println("The color is: " + newTriangle.color);
		System.out.println("The perimeter is: " + newTriangle.getPerimeter());
		System.out.println("The area is: " + newTriangle.getArea());
		System.out.println("The triangle is filled: " + newTriangle.filled);
		System.out.println(newTriangle.toString());
		
	}
	}
class SimpleTriangle extends GeometricObject{
	double side1 = 1.0;
	double side2 = 1.0;
	double side3 = 1.0;
	
	//set the sides
	SimpleTriangle(double newSide1, double newSide2, double newSide3, String color, boolean filled){
		super(color, filled);
		side3 = newSide3;
		side2 = newSide2;
		side1 = newSide1;
		setColor(color);
		setFilled(filled);
	}
	//return area
	public double getArea(){
		double s = (side1 + side2 + side3) / 2;
		double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		return area;
	}
	//return perimeter
	public double getPerimeter(){
		return side1 + side2 + side3;
	}
	//to string method
	public String toString(){
		return "Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3;
	}
}
	