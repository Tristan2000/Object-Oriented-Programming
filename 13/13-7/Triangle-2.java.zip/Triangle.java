/*
Tristan Jones
11/1/2021
*/
import java.util.Scanner;
public class Triangle{
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double side1 = 1;
		double side2 = 1;
		double side3 = 1;
		String color = "white";
		String fill = " ";
		
		//create the triangle array
		SimpleTriangle[] newTriangleArray = new SimpleTriangle[5];
		//get the length of the sides, color, and if it is filled
		for (int i = 0; i < newTriangleArray.length; i++){
			System.out.println("Triangle: " + (i + 1));
			System.out.println("Enter the length of each side of the triangle: ");
			side1 = input.nextDouble();
			side2 = input.nextDouble();
			side3 = input.nextDouble();
			System.out.println("Enter the color of the triangle: ");
			color = input.next();
			boolean filled = false;
			System.out.println("Is the Triangle filled? Yes or No: ");
			fill = input.next();
			newTriangleArray[i] = new SimpleTriangle(side1, side2, side3, color, filled);
		}
		
		//print area and howToColor
		for (int j = 0; j < newTriangleArray.length; j++){
			System.out.println("Triangle: " + (j+ 1));
			System.out.println("The area is: " + newTriangleArray[j].getArea());
			newTriangleArray[j].howToColor();
			
		}
	}
}
class SimpleTriangle extends GeometricObject implements Colorable{
	double side1 = 1.0;
	double side2 = 1.0;
	double side3 = 1.0;
	
	//set the sides
	SimpleTriangle(double newSide1, double newSide2, double newSide3, String color, boolean filled){
		super(color, filled);
		side3 = newSide3;
		side2 = newSide2;
		side1 = newSide1;
	}
	//return area
	public double getArea(){
		double s = (side1 + side2 + side3) / 2;
		double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		return area;
	}
	//return perimeter
	public double getPerimeter(){
		return side1 + side2 + side3;
	}
	//to string method
	public String toString(){
		return "Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3;
	}
	//interface
	public void howToColor(){
		System.out.println("Color all three sides");
	}
	
}

	